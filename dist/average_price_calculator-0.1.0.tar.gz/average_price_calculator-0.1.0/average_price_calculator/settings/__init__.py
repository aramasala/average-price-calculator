"""Settings module for the calculator."""
